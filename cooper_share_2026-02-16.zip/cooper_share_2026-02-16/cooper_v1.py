#!/usr/bin/env python3
"""
Cooper V1 — Productized Forecast Engine
Multi-tenant, Configuration-Driven (YAML)

Generates three reporting artifacts:
1. forecasting_daily_v4.html (Executive Brief)
2. behind_the_forecast.html (Model Explainability)
3. darcy_intel_v4.html (Actionable Intelligence)
"""

import json
import sys
import argparse
import copy
import html
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
import pandas as pd
try:
    from catboost import CatBoostRegressor
except ImportError:
    CatBoostRegressor = None

try:
    import shap
except ImportError:
    shap = None
    
import joblib

# Assumes cooper_config.py is in the same directory
try:
    from cooper_config import CooperConfig
    from cooper_features import extract_features, prepare_for_model
except ImportError:
    from cooper_config import CooperConfig
    try:
        from cooper_features import extract_features, prepare_for_model
    except ImportError:
        extract_features = None
        prepare_for_model = None

# =============================================================================
# DATA HELPERS
# =============================================================================

def extract_monthly_stats(cw_df: pd.DataFrame, config: CooperConfig) -> Dict[str, Dict]:
    """Extracts historical closed won stats."""
    df = cw_df.copy()
    df[config.close_date_field] = pd.to_datetime(df[config.close_date_field])
    
    # Filter to Closed Won if needed (using stage map)
    won_stages = [k for k, v in config.stage_map.items() if v == "Closed Won"]
    if won_stages:
        df = df[df[config.stage_field].isin(won_stages)]
        
    df['Month'] = df[config.close_date_field].dt.strftime('%Y-%m')
    stats = df.groupby('Month').agg({
        config.amount_field: ['sum', 'count']
    })
    
    output = {}
    for month, row in stats.iterrows():
        output[month] = {
            "closed": float(row[(config.amount_field, 'sum')]),
            "deals": int(row[(config.amount_field, 'count')])
        }
    return output

def extract_pipeline_som(sh_df: pd.DataFrame, config: CooperConfig) -> Dict[str, float]:
    """Extracts SOM pipeline value from snapshots using config-driven mappings."""
    df = sh_df.copy()
    date_col = config.snapshot_date_col
    val_col = config.snapshot_amount_col
    
    if date_col in df.columns and val_col in df.columns:
        df[date_col] = pd.to_datetime(df[date_col])
        som_df = df[df[date_col].dt.day == 1].copy()
        som_df['Month'] = som_df[date_col].dt.strftime('%Y-%m')
        return som_df.groupby('Month')[val_col].sum().to_dict()
            
    return {}

def extract_creation_velocity(opps_df: pd.DataFrame, config: CooperConfig) -> Dict[str, float]:
    """Trailing weekly pipeline creation."""
    df = opps_df.copy()
    df[config.created_date_field] = pd.to_datetime(df[config.created_date_field])
    df['Week'] = df[config.created_date_field].dt.to_period('W').apply(lambda r: r.start_time.strftime('%Y-%m-%d'))
    return df.groupby('Week')[config.amount_field].sum().to_dict()

# =============================================================================
# SIGNAL COMPUTATION
# =============================================================================

def compute_signals(
    opps_df: pd.DataFrame,
    config: CooperConfig,
    run_date: datetime,
    monthly_closed_hist: Dict,
    pipeline_som_hist: Dict,
    creation_hist: Dict
) -> Dict:
    
    current_month_str = run_date.strftime("%Y-%m")
    day_of_month = run_date.day
    
    # Identify Won Stages
    won_stages = [k for k, v in config.stage_map.items() if v == "Closed Won"]
    
    # 1. MTD Closed
    opps_df[config.close_date_field] = pd.to_datetime(opps_df[config.close_date_field])
    mtd_mask = (
        (opps_df[config.close_date_field].dt.strftime("%Y-%m") == current_month_str) &
        (opps_df[config.stage_field].isin(won_stages))
    )
    mtd_closed = float(opps_df[mtd_mask][config.amount_field].sum())
    
    # 2. Pipeline SOM (Current)
    open_pipeline_mask = (
        (opps_df[config.close_date_field].dt.strftime("%Y-%m") == current_month_str) &
        (~opps_df[config.stage_field].isin(won_stages)) &
        (~opps_df[config.stage_field].isin([k for k, v in config.stage_map.items() if v == "Closed Lost"]))
    )
    current_open_val = float(opps_df[open_pipeline_mask][config.amount_field].sum())
    
    som_val = float(pipeline_som_hist.get(current_month_str, current_open_val + mtd_closed))
    
    # 3. Coverage Signal
    conv_rates = [
        monthly_closed_hist[m]["closed"] / pipeline_som_hist[m]
        for m in monthly_closed_hist 
        if m in pipeline_som_hist and pipeline_som_hist[m] > 0
    ]
    avg_conv = np.mean(conv_rates) if conv_rates else 0.25
    coverage_forecast = som_val * avg_conv
    
    # 4. Pacing Signal
    if run_date.month == 12:
        next_m = run_date.replace(year=run_date.year+1, month=1, day=1)
    else:
        next_m = run_date.replace(month=run_date.month+1, day=1)
    total_days = (next_m - run_date.replace(day=1)).days
    
    if day_of_month > 0:
        pacing_forecast = mtd_closed * (total_days / day_of_month)
    else:
        pacing_forecast = 0
    pacing_forecast = min(pacing_forecast, config.monthly_target * 3.0) # Cap
    
    # 5. Creation Signal
    recent_weeks = sorted(creation_hist.keys())[-6:]
    if recent_weeks:
        avg_creation = np.mean([creation_hist[w] for w in recent_weeks])
        current_wk_cr = creation_hist[recent_weeks[-1]]
        momentum = (current_wk_cr / avg_creation) if avg_creation > 0 else 1.0
        damped_mom = 1.0 + (momentum - 1.0) * 0.5
    else:
        damped_mom = 1.0
        
    creation_forecast = coverage_forecast * damped_mom
    
    # 6. ML Scoring (Advanced)
    scored_opps = opps_df[open_pipeline_mask].copy()
    ml_forecast = 0.0
    model_path = config.get_path("model_path")
    calibrator_path = config.get_path("calibrator_path")
    
    if (
        not scored_opps.empty
        and model_path
        and model_path.exists()
        and CatBoostRegressor is not None
        and extract_features is not None
    ):
        # Use advanced feature pipeline
        features_df = extract_features(scored_opps, config)
        X, cat_cols = prepare_for_model(features_df)
        
        # Load Model
        model = CatBoostRegressor()
        model.load_model(str(model_path))
        
        # Raw Prediction
        raw_scores = model.predict(X)
        
        # Calibration (Prediction)
        if calibrator_path and calibrator_path.exists():
            calibrator = joblib.load(calibrator_path)
            # Correct usage: .predict() for IsotonicRegression
            probs = calibrator.predict(raw_scores)
            # Clip to [0, 1] just in case
            probs = np.clip(probs, 0, 1)
        else:
            probs = np.clip(raw_scores, 0, 1)
            
        scored_opps['win_probability'] = probs
        scored_opps['expected_value'] = scored_opps[config.amount_field] * probs
        ml_forecast = float(scored_opps['expected_value'].sum())
        
        # SHAP Explainability
        if shap:
            try:
                explainer = shap.TreeExplainer(model)
                shap_values = explainer.shap_values(X)
                
                # If list (for classifier), take positive class? Regressor returns array.
                # Just in case model was trained as Classifier elsewhere
                if isinstance(shap_values, list):
                    shap_values = shap_values[1]
                
                shap_records = []
                feature_names = X.columns.tolist()
                
                for i in range(len(X)):
                    sv = {feature_names[j]: float(shap_values[i][j]) for j in range(len(feature_names))}
                    # Get top 3 positive and negative
                    sorted_sv = sorted(sv.items(), key=lambda x: abs(x[1]), reverse=True)
                    top_pos = {k: v for k, v in sorted_sv if v > 0.001}
                    top_neg = {k: v for k, v in sorted_sv if v < -0.001}
                    
                    # Store
                    shap_records.append({
                        "top_positive": dict(list(top_pos.items())[:3]),
                        "top_negative": dict(list(top_neg.items())[:3]),
                        "driver": list(top_pos.keys())[0] if top_pos else "None"
                    })
                    
                scored_opps['shap_explanation'] = shap_records
            except Exception as e:
                print(f"SHAP computation failed: {e}")
                scored_opps['shap_explanation'] = "{}"
        else:
            scored_opps['shap_explanation'] = "{}"
            
    else:
        # Fallback
        scored_opps['win_probability'] = 0.1
        scored_opps['expected_value'] = scored_opps[config.amount_field] * 0.1
        scored_opps['shap_explanation'] = "{}"
        ml_forecast = float(scored_opps['expected_value'].sum())
        
    # 7. Blending (Discrete Buckets per V4.5 Validation)
    progress = day_of_month / total_days
    
    # Bucket Logic
    if day_of_month <= 7:
        # Early Month: Heavily weighted on Pipeline Coverage & Velocity
        w_cov = 0.40
        w_cre = 0.40
        w_pac = 0.10
        w_ml  = 0.10
    elif day_of_month <= 14:
        # Mid-Early: Balanced
        w_cov = 0.25
        w_cre = 0.25
        w_pac = 0.25
        w_ml  = 0.25
    elif day_of_month <= 21:
        # Mid-Late: Transition to Execution
        w_cov = 0.10
        w_cre = 0.10
        w_pac = 0.40
        w_ml  = 0.40
    else:
        # Month End: Execution Dominant
        w_cov = 0.05
        w_cre = 0.05
        w_pac = 0.45
        w_ml  = 0.45
    
    # Synthesize
    blend = (
        (coverage_forecast * w_cov) +
        (creation_forecast * w_cre) +
        ((ml_forecast + mtd_closed) * w_ml) +
        (pacing_forecast * w_pac)
    )
    
    # 8. Recoverable EV (Portfolio SHAP Aggregation)
    recoverable_ev = {}
    if 'shap_explanation' in scored_opps.columns:
        # Features known to be "levers"
        levers = ['is_stuck', 'is_disengaged', 'sales_commit_normalized', 'stage_duration']
        for lever in levers:
            impact = 0.0
            for _, row in scored_opps.iterrows():
                exp = row['shap_explanation']
                if isinstance(exp, dict) and 'top_negative' in exp:
                    # Sum impact of this lever if it appears in negative drivers
                    for f, val in exp['top_negative'].items():
                        if lever in f:
                            # EV impact is roughly proportional to SHAP value * amount
                            # This is a heuristic but matches the V4.5 spirit
                            impact += abs(val) * row[config.amount_field]
            recoverable_ev[lever] = float(impact)

    return {
        "forecast_amount": blend,
        "mtd_closed": mtd_closed,
        "pipeline_som": som_val,
        "signals": {
            "coverage": coverage_forecast,
            "pacing": pacing_forecast,
            "creation": creation_forecast,
            "ml_ev": ml_forecast
        },
        "weights": {"coverage": w_cov, "creation": w_cre, "ml": w_ml, "pacing": w_pac},
        "scored_deals": scored_opps,
        "recoverable_ev": recoverable_ev,
        "meta": {"day": day_of_month, "total_days": total_days, "progress": progress}
    }

# =============================================================================
# HTML GENERATION
# =============================================================================

def generate_html_reports(config: CooperConfig, data: Dict, run_date: datetime):
    output_dir = config.get_path("output_dir") or (config.base_dir / "output")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Process scored deals for Intel Report
    deals_df = data['scored_deals'].copy()
    
    # Enrich with Risk and Driver
    def get_risk(prob):
        if prob >= 0.7: return "Low"
        if prob >= 0.4: return "Medium"
        return "High"
        
    deals_df['risk'] = deals_df['win_probability'].apply(get_risk)
    
    def get_driver(val):
        if isinstance(val, dict):
            return val.get('driver', '')
        return ''
        
    if 'shap_explanation' in deals_df.columns:
        deals_df['top_driver'] = deals_df['shap_explanation'].apply(get_driver)
        # Also expand top positive/negative for full intel
        # But for JSON size, maybe keep it simple?
        # The intel report needs simple "Signal" column.
    else:
        deals_df['top_driver'] = ''
        
    # Identifiers (Name/Account/Owner) - assume present or mapped
    common_cols = ['Name', 'OpportunityName', 'AccountName', 'Account', 'OwnerName', 'Subject']
    found_cols = [c for c in common_cols if c in deals_df.columns]
    
    # Selection
    export_cols = [
        config.amount_field, config.stage_field, "win_probability", "expected_value", 
        "risk", "top_driver", "shap_explanation"
    ] + found_cols
    
    # Selected top 50 deals
    top_deals = deals_df.sort_values("expected_value", ascending=False).head(50).copy()
    for col in export_cols:
        if col not in top_deals.columns:
            top_deals[col] = ""
    
    # Payload for D3.js Charts
    chart_payload = {
        "signal_comparison": [
            {"label": "Coverage", "value": data['signals']['coverage']},
            {"label": "Pacing", "value": data['signals']['pacing']},
            {"label": "Creation", "value": data['signals']['creation']},
            {"label": "ML Engine", "value": data['signals']['ml_ev'] + data['mtd_closed']}
        ],
        "risk_distribution": deals_df['risk'].value_counts().to_dict(),
        "recoverable_summary": data.get('recoverable_ev', {}),
        "attainment_series": [
            {"date": "Day 1", "value": data['pipeline_som'] * 0.2}, # Heuristic series
            {"date": f"Day {data['meta']['day']}", "value": data['mtd_closed']}
        ]
    }

    report_data = {
        "meta": {
            "company": config.company_name,
            "date": run_date.strftime("%Y-%m-%d"),
            "target": config.monthly_target,
            "weights": data['weights'],
            "data_injected": True
        },
        "forecast": {
            "amount": data['forecast_amount'],
            "mtd": data['mtd_closed'],
            "som": data['pipeline_som'],
            "recoverable_ev": sum(data.get('recoverable_ev', {}).values())
        },
        "signals": data['signals'],
        "charts": chart_payload,
        "top_deals": top_deals[export_cols].fillna("").to_dict(orient="records")
    }

    def sanitize_payload(value: Any) -> Any:
        if isinstance(value, str):
            return html.escape(value, quote=True)
        if isinstance(value, list):
            return [sanitize_payload(v) for v in value]
        if isinstance(value, dict):
            return {k: sanitize_payload(v) for k, v in value.items()}
        return value

    report_data = sanitize_payload(report_data)
    behind_report_data = copy.deepcopy(report_data)
    behind_report_data["signals"]["ml_ev"] = float(data['signals']['ml_ev'] + data['mtd_closed'])
    
    # Custom serializer for numpy types
    def default(o):
        if isinstance(o, (np.int_, np.intc, np.intp, np.int8,
                          np.int16, np.int32, np.int64, np.uint8,
                          np.uint16, np.uint32, np.uint64)):
            return int(o)
        elif isinstance(o, (np.float_, np.float16, np.float32, np.float64)):
            return float(o)
        elif isinstance(o, (np.ndarray,)):
            return o.tolist()
        return str(o)

    json_str_forecast = json.dumps(report_data, default=default)
    json_str_behind = json.dumps(behind_report_data, default=default)
    json_str_intel = json_str_forecast

    # Keep logo references stable by copying the logo into the report output directory.
    logo_candidates = [
        Path(__file__).resolve().parent / "cooper_logo.jpg",
        Path(__file__).resolve().parent / "html_outputs" / "cooper_logo.jpg",
    ]
    for logo_src in logo_candidates:
        if logo_src.exists():
            shutil.copy2(logo_src, output_dir / "cooper_logo.jpg")
            break
    
    # 1. Executive Brief (Cooper Forecast)
    render_template(
        "html_outputs/cooper_forecast.html", 
        output_dir / "cooper_forecast.html", 
        json_str_forecast
    )
    
    # 2. Deep Dive (Behind the Forecast)
    render_template(
        "html_outputs/behind_the_forecast.html", 
        output_dir / "behind_the_forecast.html", # Fix filename to user request
        json_str_behind
    )
    
    # 3. Actionable Intel (Cooper Intel)
    render_template(
        "html_outputs/cooper_intel.html", 
        output_dir / "cooper_intel.html",
        json_str_intel
    )

def render_template(template_name: str, output_path: Path, json_data: str):
    module_dir = Path(__file__).resolve().parent
    candidate_paths = [
        module_dir / template_name,
        module_dir / template_name.lstrip("./"),
        Path.cwd() / template_name,
        Path(template_name),
    ]
    tpl_path = next((p for p in candidate_paths if p.exists()), None)
    if tpl_path is None:
        raise FileNotFoundError(f"Template not found: {template_name}")

    with open(tpl_path, 'r') as f:
        content = f.read()

    placeholder = "window.COOPER_DATA = {};"
    if placeholder not in content:
        raise ValueError(
            f"Template {tpl_path} is missing the required data placeholder: {placeholder}"
        )

    final_html = content.replace(placeholder, f"window.COOPER_DATA = {json_data};", 1)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w') as f:
        f.write(final_html)
    print(f"Generated: {output_path}")

# =============================================================================
# MAIN
# =============================================================================

def run(config_path: str, date_str: Optional[str] = None):
    # 1. Load Config
    config = CooperConfig.load_yaml(Path(config_path))
    
    if date_str:
        run_date = datetime.strptime(date_str, "%Y-%m-%d")
    else:
        run_date = datetime.now()
        
    print(f"Running Cooper V1 for {config.company_name} [{run_date.strftime('%Y-%m-%d')}]")
    
    # 2. Load Data
    opps_path = config.get_path("opportunities_path")
    if opps_path is None:
        raise ValueError("Config is missing opportunities_path")
    opps_df = pd.read_csv(opps_path)
    
    # Histories
    cw_hist = {}
    if config.closed_won_path:
        cw_hist = extract_monthly_stats(pd.read_csv(config.get_path("closed_won_path")), config)
        
    som_hist = {}
    if config.stage_history_path:
        som_hist = extract_pipeline_som(pd.read_csv(config.get_path("stage_history_path")), config)
        
    creation_hist = extract_creation_velocity(opps_df, config)
    
    # 3. Run Forecast
    results = compute_signals(opps_df, config, run_date, cw_hist, som_hist, creation_hist)
    
    print(f"Forecast Result: ${results['forecast_amount']:,.0f} (Target: ${config.monthly_target:,.0f})")
    
    # 4. Generate Reports
    generate_html_reports(config, results, run_date)
    
    return results

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="Path to config.yaml")
    parser.add_argument("--date", help="Simulation date YYYY-MM-DD")
    args = parser.parse_args()
    
    run(args.config, args.date)
