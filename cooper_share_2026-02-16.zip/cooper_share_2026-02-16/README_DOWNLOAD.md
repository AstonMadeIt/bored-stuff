# Cooper Share Package

Created: 2026-02-16

## What's included
- Runtime scripts: `cooper_v1.py`, `cooper_onboard.py`, `cooper_config.py`, `cooper_features.py`
- Templates: `html_outputs/`
- Sample no-connect data: `cooper_sample_data_v1/`
- Verification helper: `verify_cooper.py`

## Quick start
1. Install Python 3.10+
2. Install dependencies:
   `pip install pandas numpy catboost scikit-learn shap pyyaml joblib`
3. Run onboarding:
   `python cooper_onboard.py --data_dir cooper_sample_data_v1 --client "DemoCo"`
4. Run forecast:
   `python cooper_v1.py --config cooper_sample_data_v1/cooper_config/cooper_config.yaml`

## No-CRM workflow
- Export CSVs from the source system to a folder.
- Normalize columns to Cooper mappings via onboarding.
- Keep credentials in the source CRM only.
