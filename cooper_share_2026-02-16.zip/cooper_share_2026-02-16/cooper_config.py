from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Any, Union
import yaml


@dataclass
class CooperConfig:
    company_name: str
    monthly_target: float
    q1_target: float
    amount_field: str = "Amount"
    stage_field: str = "StageName"
    close_date_field: str = "CloseDate"
    created_date_field: str = "CreatedDate"
    stage_map: Dict[str, Any] = field(default_factory=dict)
    commit_map: Dict[str, str] = field(default_factory=dict)
    
    # Paths (stored as strings in YAML, converted to Path on load)
    base_dir: Path = field(default_factory=lambda: Path("."))
    opportunities_path: Optional[Path] = None
    stage_history_path: Optional[Path] = None
    closed_won_path: Optional[Path] = None
    activities_path: Optional[Path] = None
    accounts_path: Optional[Path] = None
    
    model_path: Optional[Path] = None
    calibrator_path: Optional[Path] = None
    output_dir: Path = field(default_factory=lambda: Path("output"))
    
    # Snapshot / History Column Mappings
    snapshot_date_col: str = "snapshot_date"
    snapshot_amount_col: str = "pipeline_value_usd"

    def __post_init__(self):
        # Ensure paths are Path objects
        path_fields = [
            'base_dir', 'opportunities_path', 'stage_history_path', 
            'closed_won_path', 'activities_path', 'accounts_path',
            'model_path', 'calibrator_path', 'output_dir'
        ]
        for pf in path_fields:
            val = getattr(self, pf)
            if val is not None and not isinstance(val, Path):
                setattr(self, pf, Path(val))

    def get_path(self, path_attr: str) -> Optional[Path]:
        val = getattr(self, path_attr)
        if val is None:
            return None
        if val.is_absolute():
            return val
        return self.base_dir / val

    @classmethod
    def load_yaml(cls, path: Union[str, Path]) -> 'CooperConfig':
        """Loads configuration from a YAML file."""
        config_path = Path(path).expanduser().resolve()
        with open(config_path, 'r') as f:
            data = yaml.safe_load(f) or {}

        config_kwargs = {}

        def set_if_present(key: str, value: Any):
            if value is not None:
                config_kwargs[key] = value

        # Resolve base_dir from config value (if present) or config file location.
        # This makes path resolution portable across scheduled jobs with different cwd.
        raw_base_dir = data.get('base_dir')
        if raw_base_dir:
            base_dir = Path(raw_base_dir)
            if not base_dir.is_absolute():
                base_dir = (config_path.parent / base_dir).resolve()
        else:
            base_dir = config_path.parent
        config_kwargs['base_dir'] = base_dir

        if 'company' in data:
            set_if_present('company_name', data['company'].get('name'))

        if 'targets' in data:
            set_if_present('monthly_target', data['targets'].get('monthly'))
            set_if_present('q1_target', data['targets'].get('q1'))

        if 'salesforce' in data:
            sf = data['salesforce']
            set_if_present('amount_field', sf.get('amount_field'))
            set_if_present('stage_field', sf.get('stage_field'))
            set_if_present('close_date_field', sf.get('close_date_field'))
            set_if_present('created_date_field', sf.get('created_date_field'))
            set_if_present('stage_map', sf.get('stage_map', {}))
            set_if_present('commit_map', sf.get('commit_map', {}))

        if 'model' in data:
            set_if_present('model_path', data['model'].get('path'))
            set_if_present('calibrator_path', data['model'].get('calibrator'))

        if 'output' in data:
            set_if_present('output_dir', data['output'].get('dashboard_dir'))

        if 'data' in data:
            d = data['data']
            set_if_present('opportunities_path', d.get('opportunities'))
            set_if_present('stage_history_path', d.get('stage_history'))
            set_if_present('closed_won_path', d.get('closed_won'))

        # Fallback for direct keys if the YAML is flat
        for k, v in data.items():
            if (
                k not in ['company', 'targets', 'salesforce', 'model', 'output', 'data']
                and k in cls.__dataclass_fields__
                and v is not None
            ):
                config_kwargs[k] = v

        return cls(**config_kwargs)

    def save_yaml(self, path: Union[str, Path]):
        """Saves configuration to a YAML file."""
        base = self.base_dir if isinstance(self.base_dir, Path) else Path(self.base_dir)

        def path_for_yaml(p: Optional[Path]) -> Optional[str]:
            if p is None:
                return None
            p = p if isinstance(p, Path) else Path(p)
            if p.is_absolute():
                try:
                    return str(p.relative_to(base))
                except ValueError:
                    return str(p)
            return str(p)

        # Structure the data as per the user's preference
        data = {
            'base_dir': str(base),
            'company': {
                'name': self.company_name
            },
            'targets': {
                'monthly': self.monthly_target,
                'q1': self.q1_target
            },
            'salesforce': {
                'amount_field': self.amount_field,
                'stage_field': self.stage_field,
                'close_date_field': self.close_date_field,
                'created_date_field': self.created_date_field,
                'stage_map': self.stage_map,
                'commit_map': self.commit_map
            },
            'model': {
                'path': path_for_yaml(self.model_path),
                'calibrator': path_for_yaml(self.calibrator_path)
            },
            'output': {
                'dashboard_dir': path_for_yaml(self.output_dir)
            },
            'data': {
                'opportunities': path_for_yaml(self.opportunities_path),
                'stage_history': path_for_yaml(self.stage_history_path),
                'closed_won': path_for_yaml(self.closed_won_path),
            }
        }

        with open(path, 'w') as f:
            yaml.dump(data, f, sort_keys=False, default_flow_style=False)
