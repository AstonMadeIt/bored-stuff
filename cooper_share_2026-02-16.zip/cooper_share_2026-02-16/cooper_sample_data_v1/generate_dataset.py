import csv
import random
from datetime import date, timedelta
from pathlib import Path

random.seed(46)
out_dir = Path(__file__).resolve().parent

start = date(2025, 7, 1)
end = date(2026, 2, 14)
days_range = (end - start).days

regions = ["Northeast", "Southeast", "Midwest", "Southwest", "West"]
industries = [
    "Home Services",
    "Dental Group",
    "Multi-Location Retail",
    "Legal Services",
    "B2B SaaS",
    "Logistics",
    "Healthcare Clinics",
    "Commercial Real Estate",
]

lead_sources = ["Inbound", "Referral", "Paid Search", "Partner", "Outbound", "Event", "Webinar"]
stages = ["Prospecting", "Qualification", "Value", "Proposal", "Negotiation", "Closed Won", "Closed Lost"]
contract_status = ["Not Sent", "Sent", "Viewed", "Signed", "Declined", "Expired"]
forecast_categories = ["Pipeline", "Best Case", "Commit", "Closed"]
activity_types = ["Call", "Email", "Meeting", "Demo", "Proposal Review", "Follow-up"]
outcomes = ["Positive", "Neutral", "Negative", "No Response"]
channels = ["Google Ads", "Meta Ads", "Email", "Webinar", "Partner", "LinkedIn", "Content"]

reps = [
    ("U001", "Amy Carter"),
    ("U002", "Luis Moreno"),
    ("U003", "Dana Kim"),
    ("U004", "Noah Patel"),
    ("U005", "Sofia Grant"),
    ("U006", "Marcus Lee"),
]

# Users
with (out_dir / "users.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["owner_id", "owner_name", "role", "region", "quota_qtr_usd"])
    for owner_id, owner_name in reps:
        w.writerow([
            owner_id,
            owner_name,
            random.choice(["Account Executive", "RevOps Manager", "Sales Manager"]),
            random.choice(regions),
            random.choice([250000, 300000, 350000, 400000]),
        ])

# Accounts
accounts = []
with (out_dir / "accounts.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "account_id",
        "account_name",
        "industry",
        "segment",
        "owner_id",
        "employees",
        "annual_revenue_usd",
        "region",
        "created_date",
        "last_activity_date",
        "health_score",
        "churn_risk_tier",
    ])
    for i in range(1, 56):
        account_id = f"A{i:04d}"
        industry = random.choice(industries)
        segment = random.choices(["SMB", "Mid-Market", "Enterprise"], weights=[0.65, 0.3, 0.05])[0]
        employees = random.randint(8, 20) if segment == "SMB" else random.randint(21, 180)
        annual_revenue = random.randint(800_000, 4_500_000) if segment == "SMB" else random.randint(4_000_000, 35_000_000)
        created = start + timedelta(days=random.randint(0, 210))
        last_act = end - timedelta(days=random.randint(0, 35))
        health = max(38, min(97, int(random.gauss(74, 11))))
        churn = "High" if health < 58 else "Medium" if health < 76 else "Low"
        owner_id = random.choice(reps)[0]
        account_name = f"{random.choice(['Northstar','Summit','Crescent','Harbor','Maple','Vertex','Brightline','Atlas'])} {random.choice(['Group','Partners','Holdings','Services','Collective','Systems','Advisors'])}"
        row = [
            account_id,
            account_name,
            industry,
            segment,
            owner_id,
            employees,
            annual_revenue,
            random.choice(regions),
            created.isoformat(),
            last_act.isoformat(),
            health,
            churn,
        ]
        accounts.append(row)
        w.writerow(row)

# Contacts
contacts = []
with (out_dir / "contacts.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "contact_id",
        "account_id",
        "contact_name",
        "title",
        "email",
        "phone",
        "decision_role",
        "last_email_date",
        "engagement_score",
        "opt_in_status",
    ])
    first_names = ["Alex", "Jordan", "Taylor", "Riley", "Morgan", "Casey", "Jamie", "Avery", "Cameron", "Parker"]
    last_names = ["Reed", "Lopez", "Nguyen", "Shah", "Turner", "Diaz", "Hayes", "Bennett", "Wright", "Cole"]
    titles = ["Owner", "COO", "VP Sales", "Director Operations", "Marketing Director", "Controller", "Head of Growth"]
    for i in range(1, 161):
        account = random.choice(accounts)
        account_id = account[0]
        fn = random.choice(first_names)
        ln = random.choice(last_names)
        name = f"{fn} {ln}"
        role = random.choice(["Decision Maker", "Economic Buyer", "Champion", "Influencer"])
        eng = max(12, min(98, int(random.gauss(61, 19))))
        email_date = end - timedelta(days=random.randint(0, 60))
        row = [
            f"C{i:04d}",
            account_id,
            name,
            random.choice(titles),
            f"{fn.lower()}.{ln.lower()}@{account[1].lower().replace(' ', '').replace('&','')}.com",
            f"+1-555-{random.randint(200,999)}-{random.randint(1000,9999)}",
            role,
            email_date.isoformat(),
            eng,
            random.choices(["Subscribed", "Unsubscribed"], weights=[0.9, 0.1])[0],
        ]
        contacts.append(row)
        w.writerow(row)

# Campaigns
campaigns = []
with (out_dir / "marketing_campaigns.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "campaign_id",
        "campaign_name",
        "channel",
        "start_date",
        "end_date",
        "spend_usd",
        "mqls",
        "sqls",
        "won_deals",
        "revenue_influenced_usd",
        "cac_usd",
        "roi_pct",
        "status",
    ])
    for i in range(1, 27):
        sdate = start + timedelta(days=random.randint(0, 180))
        length = random.randint(20, 70)
        edate = min(end, sdate + timedelta(days=length))
        spend = random.randint(4_000, 55_000)
        mqls = random.randint(40, 450)
        sqls = int(mqls * random.uniform(0.25, 0.55))
        won = int(sqls * random.uniform(0.08, 0.24))
        rev = won * random.randint(7_000, 55_000)
        cac = max(130, int(spend / max(1, won)))
        roi = round(((rev - spend) / max(1, spend)) * 100, 1)
        row = [
            f"MKT{i:03d}",
            f"{random.choice(['Pipeline Accelerator','Demand Sprint','Revive Lost Leads','CFO Brief Series','QBR Push','Revenue Rescue'])} {i}",
            random.choice(channels),
            sdate.isoformat(),
            edate.isoformat(),
            spend,
            mqls,
            sqls,
            won,
            rev,
            cac,
            roi,
            "Active" if edate >= end - timedelta(days=20) else "Completed",
        ]
        campaigns.append(row)
        w.writerow(row)

campaign_ids = [c[0] for c in campaigns]

# Opportunities
opps = []
with (out_dir / "opportunities.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "opportunity_id",
        "account_id",
        "opportunity_name",
        "stage",
        "amount_usd",
        "created_date",
        "close_date",
        "probability_pct",
        "last_activity_date",
        "next_step_date",
        "days_in_stage",
        "lead_source",
        "campaign_id",
        "owner_id",
        "docusign_status",
        "contract_sent_date",
        "is_stale",
        "at_risk_reason",
        "predicted_win_probability_pct",
        "forecast_category",
    ])
    risk_reasons = [
        "No activity 10+ days",
        "Decision maker not engaged",
        "Contract pending signature",
        "Budget pushed to next quarter",
        "Competing vendor in final round",
        "Low technical fit",
        "No mutual action plan",
    ]

    for i in range(1, 191):
        account = random.choice(accounts)
        account_id = account[0]
        created = start + timedelta(days=random.randint(0, days_range - 20))
        stage = random.choices(
            stages,
            weights=[18, 20, 18, 14, 11, 11, 8],
        )[0]
        amount = random.randint(4_000, 175_000)
        close = created + timedelta(days=random.randint(15, 120))
        close = min(close, end + timedelta(days=30))
        base_prob = {
            "Prospecting": 12,
            "Qualification": 24,
            "Value": 38,
            "Proposal": 54,
            "Negotiation": 72,
            "Closed Won": 100,
            "Closed Lost": 0,
        }[stage]
        noise = random.randint(-12, 10)
        prob = max(0, min(100, base_prob + noise))
        days_in_stage = random.randint(2, 42)
        if stage in ["Proposal", "Negotiation"] and random.random() < 0.35:
            days_in_stage = random.randint(25, 72)
        last_act = end - timedelta(days=random.randint(0, 36))
        next_step = end + timedelta(days=random.randint(-4, 28))
        stale = "TRUE" if (end - last_act).days >= 10 and stage not in ["Closed Won", "Closed Lost"] else "FALSE"
        docusign = random.choices(contract_status, weights=[34, 24, 12, 16, 5, 9])[0]
        if stage in ["Closed Won", "Closed Lost"]:
            docusign = "Signed" if stage == "Closed Won" else random.choice(["Declined", "Expired"])
        contract_sent = ""
        if docusign in ["Sent", "Viewed", "Signed", "Declined", "Expired"]:
            cs_date = end - timedelta(days=random.randint(0, 40))
            contract_sent = cs_date.isoformat()
        risk_reason = ""
        if stale == "TRUE" or (docusign in ["Sent", "Viewed"] and stage == "Negotiation"):
            risk_reason = random.choice(risk_reasons)

        pred = prob + random.randint(-18, 16)
        if stale == "TRUE":
            pred -= random.randint(5, 18)
        if docusign == "Viewed" and contract_sent:
            pred -= random.randint(6, 15)
        if docusign == "Signed":
            pred = max(pred, 88)
        pred = max(1, min(99, pred))

        fcat = random.choice(forecast_categories)
        if pred > 80:
            fcat = "Commit"
        if stage == "Closed Won":
            fcat = "Closed"

        row = [
            f"O{i:05d}",
            account_id,
            f"{account[1]} - {random.choice(['Expansion', 'Renewal', 'Retainer', 'New Program', 'Marketing OS'])}",
            stage,
            amount,
            created.isoformat(),
            close.isoformat(),
            prob,
            last_act.isoformat(),
            next_step.isoformat(),
            days_in_stage,
            random.choice(lead_sources),
            random.choice(campaign_ids),
            random.choice(reps)[0],
            docusign,
            contract_sent,
            stale,
            risk_reason,
            pred,
            fcat,
        ]
        opps.append(row)
        w.writerow(row)

# Activities
with (out_dir / "activities.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "activity_id",
        "opportunity_id",
        "account_id",
        "owner_id",
        "activity_type",
        "activity_date",
        "outcome",
        "duration_min",
        "sentiment",
        "next_action_set",
        "next_action_due_date",
    ])
    aid = 1
    sentiments = ["Positive", "Neutral", "Concerned", "Blocked"]
    for opp in opps:
        opp_id = opp[0]
        account_id = opp[1]
        num = random.randint(2, 8)
        for _ in range(num):
            act_date = start + timedelta(days=random.randint(0, days_range))
            outcome = random.choice(outcomes)
            next_set = random.choices(["TRUE", "FALSE"], weights=[0.76, 0.24])[0]
            next_due = ""
            if next_set == "TRUE":
                next_due = (act_date + timedelta(days=random.randint(1, 14))).isoformat()
            w.writerow([
                f"ACT{aid:06d}",
                opp_id,
                account_id,
                random.choice(reps)[0],
                random.choice(activity_types),
                act_date.isoformat(),
                outcome,
                random.randint(8, 90),
                random.choice(sentiments),
                next_set,
                next_due,
            ])
            aid += 1

# Invoices
with (out_dir / "invoices.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "invoice_id",
        "account_id",
        "invoice_date",
        "due_date",
        "paid_date",
        "status",
        "amount_usd",
        "source_system",
        "days_to_pay",
        "is_overdue",
    ])
    iid = 1
    for account in accounts:
        account_id = account[0]
        invoice_count = random.randint(3, 12)
        for _ in range(invoice_count):
            inv_date = start + timedelta(days=random.randint(0, days_range - 10))
            due = inv_date + timedelta(days=random.choice([15, 30, 45]))
            status = random.choices(["Paid", "Open", "Partially Paid", "Written Off"], weights=[0.68, 0.21, 0.08, 0.03])[0]
            paid_date = ""
            days_to_pay = ""
            overdue = "FALSE"
            if status == "Paid":
                pd = due - timedelta(days=random.randint(-8, 16))
                paid_date = pd.isoformat()
                days_to_pay = (pd - inv_date).days
                overdue = "TRUE" if pd > due else "FALSE"
            elif status == "Partially Paid":
                pd = due + timedelta(days=random.randint(1, 20))
                paid_date = pd.isoformat()
                days_to_pay = (pd - inv_date).days
                overdue = "TRUE"
            else:
                overdue = "TRUE" if due < end else "FALSE"
            w.writerow([
                f"INV{iid:06d}",
                account_id,
                inv_date.isoformat(),
                due.isoformat(),
                paid_date,
                status,
                random.randint(1200, 42000),
                random.choice(["Stripe", "QuickBooks"]),
                days_to_pay,
                overdue,
            ])
            iid += 1

# Pipeline snapshots
with (out_dir / "pipeline_snapshots.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "snapshot_date",
        "stage",
        "opportunity_count",
        "pipeline_value_usd",
        "avg_days_in_stage",
    ])
    snapshot_day = date(2025, 9, 1)
    while snapshot_day <= end:
        for stage in stages:
            if stage in ["Closed Won", "Closed Lost"]:
                mult = 0.45
            elif stage in ["Proposal", "Negotiation"]:
                mult = 0.7
            else:
                mult = 1.0
            base_count = int(random.randint(16, 62) * mult)
            val = base_count * random.randint(4500, 34000)
            avg_days = random.randint(6, 41)
            if stage in ["Proposal", "Negotiation"]:
                avg_days = random.randint(15, 58)
            w.writerow([
                snapshot_day.isoformat(),
                stage,
                base_count,
                val,
                avg_days,
            ])
        snapshot_day += timedelta(days=7)

# Model predictions (MLflow style output)
with (out_dir / "model_predictions.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "prediction_id",
        "opportunity_id",
        "scored_at",
        "model_name",
        "model_version",
        "win_probability_pct",
        "risk_bucket",
        "top_reason_1",
        "top_reason_2",
        "recommended_action",
    ])
    reasons = [
        ("Low recent activity", "No next-step date", "Set exec call and next-step today"),
        ("Long stage aging", "Weak champion engagement", "Schedule multi-threading outreach"),
        ("Contract viewed but unsigned", "Legal stalled", "Call procurement and send redline summary"),
        ("Healthy activity cadence", "Economic buyer engaged", "Advance to mutual close plan"),
        ("High email opens, low meetings", "Messaging mismatch", "Send value recap and case study"),
    ]
    pid = 1
    for opp in opps:
        o_id = opp[0]
        pred = int(opp[18])
        if pred < 30:
            bucket = "High Risk"
        elif pred < 60:
            bucket = "Watch"
        else:
            bucket = "Healthy"
        r1, r2, action = random.choice(reasons)
        w.writerow([
            f"PRED{pid:06d}",
            o_id,
            end.isoformat(),
            "cooper_win_model",
            random.choice(["1.0.0", "1.1.0", "1.2.0"]),
            pred,
            bucket,
            r1,
            r2,
            action,
        ])
        pid += 1

readme = out_dir / "README.md"
readme.write_text(
    """# Cooper Sample Dataset v1\n\nThis dataset is synthetic and safe for demos. It is designed for a no-connect microsite and mirrors common Salesforce exports for Sales Ops + Marketing Ops + contract status signals.\n\n## Files (multi-tab equivalent)\n- `users.csv`: sales owners and quota context\n- `accounts.csv`: account health and churn risk\n- `contacts.csv`: decision-maker/contact engagement\n- `opportunities.csv`: pipeline with stale flags, stage aging, DocuSign status field\n- `activities.csv`: calls/emails/meetings with next-action coverage\n- `marketing_campaigns.csv`: spend, MQL->SQL->won flow, ROI\n- `invoices.csv`: Stripe/QuickBooks payment behavior\n- `pipeline_snapshots.csv`: weekly trend snapshots by stage\n- `model_predictions.csv`: MLflow-style model scoring output\n\n## Demo hooks to show in 60-90 seconds\n1. At-risk revenue: sum `amount_usd` where `is_stale=TRUE` and stage not closed.\n2. Ghost deals: stale opportunities with `days_in_stage > 25`.\n3. Contract risk: `docusign_status in (Sent, Viewed)` and contract older than 10 days.\n4. Rep execution gaps: activities where `next_action_set=FALSE`.\n5. Campaign efficiency: high spend + low SQL conversion or negative ROI.\n6. Cash risk: overdue invoices and rising `days_to_pay`.\n\n## Salesforce mapping notes\n- `opportunities.csv` -> Opportunity object export\n- `accounts.csv` -> Account object export\n- `contacts.csv` -> Contact object export\n- `activities.csv` -> Task/Event exports\n- `docusign_status` is modeled as a Salesforce Opportunity field populated by DocuSign integration\n\n## Suggested upload order for a no-connect demo\n1. `opportunities.csv`\n2. `activities.csv`\n3. `accounts.csv`\n4. `invoices.csv`\n5. optional: `marketing_campaigns.csv`, `model_predictions.csv`\n""",
    encoding="utf-8",
)

# quick row count summary
summary_path = out_dir / "_row_counts.txt"
counts = []
for name in [
    "users.csv",
    "accounts.csv",
    "contacts.csv",
    "opportunities.csv",
    "activities.csv",
    "marketing_campaigns.csv",
    "invoices.csv",
    "pipeline_snapshots.csv",
    "model_predictions.csv",
]:
    with (out_dir / name).open() as f:
        rows = sum(1 for _ in f) - 1
    counts.append((name, rows))

with summary_path.open("w") as f:
    for name, rows in counts:
        f.write(f"{name}: {rows}\n")

print("Generated dataset in", out_dir)
for name, rows in counts:
    print(f"{name}: {rows}")
