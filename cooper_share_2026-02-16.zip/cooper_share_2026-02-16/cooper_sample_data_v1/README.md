# Cooper Sample Dataset v1

This dataset is synthetic and safe for demos. It is designed for a no-connect microsite and mirrors common Salesforce exports for Sales Ops + Marketing Ops + contract status signals.

## Files (multi-tab equivalent)
- `users.csv`: sales owners and quota context
- `accounts.csv`: account health and churn risk
- `contacts.csv`: decision-maker/contact engagement
- `opportunities.csv`: pipeline with stale flags, stage aging, DocuSign status field
- `activities.csv`: calls/emails/meetings with next-action coverage
- `marketing_campaigns.csv`: spend, MQL->SQL->won flow, ROI
- `invoices.csv`: Stripe/QuickBooks payment behavior
- `pipeline_snapshots.csv`: weekly trend snapshots by stage
- `model_predictions.csv`: MLflow-style model scoring output

## Demo hooks to show in 60-90 seconds
1. At-risk revenue: sum `amount_usd` where `is_stale=TRUE` and stage not closed.
2. Ghost deals: stale opportunities with `days_in_stage > 25`.
3. Contract risk: `docusign_status in (Sent, Viewed)` and contract older than 10 days.
4. Rep execution gaps: activities where `next_action_set=FALSE`.
5. Campaign efficiency: high spend + low SQL conversion or negative ROI.
6. Cash risk: overdue invoices and rising `days_to_pay`.

## Salesforce mapping notes
- `opportunities.csv` -> Opportunity object export
- `accounts.csv` -> Account object export
- `contacts.csv` -> Contact object export
- `activities.csv` -> Task/Event exports
- `docusign_status` is modeled as a Salesforce Opportunity field populated by DocuSign integration

## Suggested upload order for a no-connect demo
1. `opportunities.csv`
2. `activities.csv`
3. `accounts.csv`
4. `invoices.csv`
5. optional: `marketing_campaigns.csv`, `model_predictions.csv`
