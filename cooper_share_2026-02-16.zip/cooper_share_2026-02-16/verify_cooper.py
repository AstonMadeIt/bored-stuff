
import sys
from pathlib import Path
import pandas as pd
import joblib

# Add current dir to path
sys.path.append(str(Path.cwd()))

from cooper_config import CooperConfig
from cooper_onboard import train_model
from cooper_v1 import run as run_forecast

def verify():
    print("--- STARTING VERIFICATION ---")
    
    # 1. Setup Paths
    base_dir = Path.cwd()
    sample_dir = base_dir / "cooper_sample_data_v1"
    output_dir = base_dir / "verification_output"
    output_dir.mkdir(exist_ok=True)
    
    # 2. Mock Configuration
    print("Creating Config...")
    config = CooperConfig(
        company_name="Verification Corp",
        monthly_target=1_500_000,
        q1_target=4_500_000,
        amount_field="amount_usd",
        stage_field="stage",
        close_date_field="close_date",
        created_date_field="created_date",
        stage_map={
            "Discovery": 1,
            "Qualification": 2,
            "Proposal": 3,
            "Negotiation": 4,
            "Closed Won": "Closed Won",
            "Closed Lost": "Closed Lost"
        },
        commit_map={},
        base_dir=base_dir,
        opportunities_path=sample_dir / "opportunities.csv",
        stage_history_path=sample_dir / "pipeline_snapshots.csv", 
        # closed_won_path could be subset of opps or separate, 
        # cooper_v1 extracts from opps if not provided separate, but let's check config logic
        # Actually cooper_v1 checks config.closed_won_path specifically. 
        # If None, it relies on MTD from opps, but historical might be missing.
        # Let's point to opportunities.csv as closed_won_path for simplicity of obtaining history?
        # No, extract_monthly_stats expects closed won rows. 
        closed_won_path=sample_dir / "opportunities.csv", 
        output_dir=output_dir
    )
    
    # 3. Train Models (to have valid files)
    print("Training Dummy Models...")
    opps_df = pd.read_csv(config.opportunities_path)
    model, calibrator = train_model(opps_df, config)
    
    if model:
        model_path = output_dir / "model.cbm"
        model.save_model(str(model_path))
        config.model_path = model_path
    
    if calibrator:
        cal_path = output_dir / "calibrator.pkl"
        joblib.dump(calibrator, cal_path)
        config.calibrator_path = cal_path
        
    # 4. Save Config
    config_path = output_dir / "config.yaml"
    config.save_yaml(config_path)
    print(f"Config saved to {config_path}")
    
    # 5. Run Cooper V1
    print("Running Cooper V1...")
    results = run_forecast(str(config_path), date_str="2025-10-15")
    
    # 6. REGRESSION TEST: Probability Calibration & Spread
    print("\n[Regression Test] Validating ML Calibration...")
    if 'scored_deals' in results and not results['scored_deals'].empty:
        scored = results['scored_deals']
        probs = scored['win_probability']
        std_dev = probs.std()
        mean_prob = probs.mean()
        
        print(f"  > Mean Win Probability: {mean_prob:.4f}")
        print(f"  > Probability Std Dev: {std_dev:.4f}")
        
        # Methodology Check: We expect std_dev > 0.05 even on dummy data with variation
        # Below 0.02 strongly suggests calibration collapse
        if std_dev < 0.05:
            print("  [FAIL] Probability Spread is too narrow ($<0.05$). The model is too uniform.")
            success = False
        else:
            print("  [PASS] Probability Spread is healthy.")
            success = True
            
        # Check SHAP drivers
        if 'top_driver' in scored.columns:
            drivers = scored['top_driver'].unique()
            print(f"  > Unique SHAP Drivers: {list(drivers)}")
    else:
        print("  [FAIL] No deals scored.")
        success = False

    # 7. Check Outputs
    expected_files = ["cooper_forecast.html", "behind_the_forecast.html", "cooper_intel.html"]
    missing = [f for f in expected_files if not (output_dir / f).exists()]
            
    if missing or not success:
        print(f"\nVERIFICATION FAILED. Missing: {missing}")
        sys.exit(1)
    else:
        print("\nVERIFICATION SUCCESS: All logic and reports validated.")
        sys.exit(0)

if __name__ == "__main__":
    verify()
