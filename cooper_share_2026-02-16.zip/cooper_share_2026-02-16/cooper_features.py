
import pandas as pd
import numpy as np
from datetime import datetime
from cooper_config import CooperConfig

def extract_features(df: pd.DataFrame, config: CooperConfig) -> pd.DataFrame:
    """
    Extracts the 8 core features used in the V4.5 model.
    Handles field normalization, missing values, and derived metrics.
    """
    features = pd.DataFrame(index=df.index)
    now = datetime.now()
    now_ts = pd.Timestamp.now()

    # 1. AMOUNT (Normalized)
    # -----------------------
    features["amount"] = pd.to_numeric(df[config.amount_field], errors="coerce").fillna(0)
    
    # 2. MATCH IDENTIFIERS (for tracebacks)
    # -------------------------------------
    # Try to find an ID and Name for reports
    id_cols = ["Id", "OpportunityId", "OPPORTUNITY_ID", "id"]
    name_cols = ["Name", "OpportunityName", "OPPORTUNITY_NAME", "name"]
    
    features["id"] = "Unknown"
    for c in id_cols:
        if c in df.columns:
            features["id"] = df[c].fillna("Unknown")
            break
            
    features["name"] = "Unknown"
    for c in name_cols:
        if c in df.columns:
            features["name"] = df[c].fillna("Unknown")
            break

    # 3. AGE (Days since creation)
    # ----------------------------
    # Priority: Calculated Field -> Config Field -> Calculation
    age_source = "default"
    
    # Try common explicit fields
    age_col_options = ["opportunity_age", "Opportunity_Age", "opp_age", "age", "Days_Open__c"]
    for col in age_col_options:
        if col in df.columns:
            features["age"] = pd.to_numeric(df[col], errors="coerce").fillna(60).clip(lower=0).astype(int)
            age_source = f"sfdc:{col}"
            break
            
    if age_source == "default":
        # Calculate from CreatedDate
        create_col = config.created_date_field
        if create_col in df.columns:
            created_dt = pd.to_datetime(df[create_col], errors="coerce", utc=True)
            if created_dt.dt.tz is not None:
                created_dt = created_dt.dt.tz_localize(None)
            features["age"] = (now_ts - created_dt).dt.days.fillna(60).clip(lower=0).astype(int)
            age_source = f"calc:{create_col}"
        else:
             features["age"] = 60 # Fallback

    # 4. STAGE DURATION (Days in current stage)
    # -----------------------------------------
    stage_dur_source = "default"
    stage_dur_options = ["days_at_current_stage", "Days_in_Stage__c", "stage_duration", "Stage_Duration__c"]
    
    for col in stage_dur_options:
        if col in df.columns:
             features["stage_duration"] = pd.to_numeric(df[col], errors="coerce").fillna(14).clip(lower=0).astype(int)
             stage_dur_source = f"sfdc:{col}"
             break
             
    if stage_dur_source == "default":
        # Try LastStageChangeDate
        stage_change_cols = ["LastStageChangeDate", "Last_Stage_Change_Date__c", "last_stage_change"]
        for col in stage_change_cols:
             if col in df.columns:
                stage_dt = pd.to_datetime(df[col], errors="coerce", utc=True)
                if stage_dt.dt.tz is not None:
                    stage_dt = stage_dt.dt.tz_localize(None)
                features["stage_duration"] = (now_ts - stage_dt).dt.days.fillna(14).clip(lower=0).astype(int)
                stage_dur_source = f"calc:{col}"
                break
                
    if stage_dur_source == "default":
        features["stage_duration"] = 14

    # Sanity check: duration shouldn't exceed age
    features["stage_duration"] = features[["stage_duration", "age"]].min(axis=1)

    # 5. DERIVED VELOCITY FLAGS
    # -------------------------
    # Is Stuck: > 30 days in stage (V4.5 definition)
    features["is_stuck"] = (features["stage_duration"] > 30).astype(int)
    
    # Stage/Age Ratio
    features["stage_duration_ratio"] = (features["stage_duration"] / features["age"].replace(0, 1)).clip(upper=1)

    # Is Disengaged: Next Step not updated in 14 days
    # Need next step field
    next_step_options = ["days_since_next_step_modified", "Next_Step_Update__c", "LastActivityDate"]
    has_engagement = False
    
    for col in next_step_options:
        if col in df.columns:
             # If it's a date, calc diff
             if "Date" in col:
                 act_dt = pd.to_datetime(df[col], errors="coerce", utc=True)
                 if act_dt.dt.tz is not None: act_dt = act_dt.dt.tz_localize(None)
                 days_since = (now_ts - act_dt).dt.days.fillna(30)
                 features["is_disengaged"] = (days_since > 14).astype(int)
             else:
                 # Assume it's days count
                 days = pd.to_numeric(df[col], errors="coerce").fillna(30)
                 features["is_disengaged"] = (days > 14).astype(int)
             has_engagement = True
             break
             
    if not has_engagement:
        # Proxy: if in stage > 21 days, likely disengaged
        features["is_disengaged"] = (features["stage_duration"] > 21).astype(int)


    # 6. CATEGORICALS (Normalized)
    # ----------------------------
    # Stage
    # Use config map to get standardized stage names if possible, else raw
    # We map to the Keys of the stage map (Display Names)
    # Config stage_map is { "Raw Name": "Bucket/Display Name" } ? 
    # Actually CooperConfig.stage_map usually maps "Raw": ID (int) for processing?
    # Let's check config.py. It creates config: stage_map = { "Discovery": 1, ... }
    # So we want to map raw stage field to these keys if possible, or just usage raw.
    # V4.5 uses "stage_normalized".
    
    raw_stage_col = config.stage_field
    
    # Invert the config map if it's name->id to get normalization groupings
    # Or just use the raw stage if no grouping provided.
    # For ML, high cardinality is okay for CatBoost, but grouping helps.
    features["stage_normalized"] = df[raw_stage_col].astype(str).fillna("Unknown")
    
    # Sales Commit
    # Config commit_map is { "Raw": "Standard" }
    commit_col = "ForecastCategoryName" # Default standard
    if "ForecastCategory" in df.columns: commit_col = "ForecastCategory"
    if "commit" in df.columns: commit_col = "commit"
    
    if commit_col in df.columns:
        # Apply mapping if exists
        features["sales_commit_normalized"] = df[commit_col].map(config.commit_map).fillna(df[commit_col])
    else:
        features["sales_commit_normalized"] = "Developing" # Default
        
    # Segment (Binning)
    seg = pd.cut(
        features["amount"],
        bins=[-1, 25_000, 100_000, 500_000, float("inf")],
        labels=["Small", "Mid-Market", "Enterprise", "Strategic"],
    )
    features["segment"] = seg.astype(str).replace("nan", "Mid-Market")
    
    # 7. METADATA
    # -----------
    features["close_date"] = df[config.close_date_field]
    features["owner"] = df["OwnerId"] if "OwnerId" in df.columns else "Unknown"
    
    # Return features dataframe
    # We keep amount, age, etc. as columns
    return features.fillna(0)

def prepare_for_model(features_df: pd.DataFrame):
    """
    Selects only the columns needed for training/inference.
    """
    model_cols = [
        "amount", "age", "stage_duration", 
        "stage_normalized", "sales_commit_normalized", 
        "segment", "is_stuck", "is_disengaged", 
        "stage_duration_ratio"
    ]
    
    # Ensure all exist
    X = pd.DataFrame(index=features_df.index)
    for col in model_cols:
        if col in features_df.columns:
             X[col] = features_df[col]
        else:
             X[col] = 0
             
    # Handle categoricals for CatBoost
    cat_cols = ["stage_normalized", "sales_commit_normalized", "segment"]
    for col in cat_cols:
        X[col] = X[col].astype(str).replace("nan", "Unknown")
        
    return X, cat_cols
