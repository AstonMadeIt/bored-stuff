# Cooper V1.1 Upgrade - Machine Learning Port

We have successfully ported the advanced "Muscle" from the V4.5 prototype into the Cooper V1 chassis.

## Upgrade Summary

### 1. Feature Engineering (`cooper_features.py`)
- **Ported**: Full 8-feature extraction pipeline.
- **Components**:
    - `age` (Days since creation)
    - `stage_duration` (Days in current stage)
    - `stage_normalized` / `sales_commit_normalized`
    - `segment` (Deal size buckets)
    - `is_stuck` (>30 days in stage)
    - `is_disengaged` (>14 days w/o update)
    - `stage_duration_ratio` (Velocity metric)

### 2. Advanced ML Training (`cooper_onboard.py`)
- **Upgraded**: Now trains a `CatBoostRegressor` on the full feature set instead of `Amount` only.
- **Calibration**: Uses correct `IsotonicRegression.predict()` for probability calibration.
- **Fallback**: Gracefully degrades to simple regression if dependencies are missing.

### 3. Forecast Engine (`cooper_v1.py`)
- **SHAP Integration**: Added `shap.TreeExplainer` to generate:
    - Deal-specific drivers (e.g., "Stuck in Negotiation (+14 days)")
    - `top_driver` field for the Intel Report.
- **Discrete Blending**: Implemented Day-of-Month buckets:
    - **Day 1-7**: Coverage (40%) / Creation (40%)
    - **Day 8-14**: Balanced (25% each)
    - **Day 15-21**: Pacing (40%) / ML (40%)
    - **Day 22+**: Execution heavy (45% Pacing / 45% ML)

### 4. Verification (`verify_cooper.py`)
- **Regression Test**: Added automated check for probability calibration spread (std dev > 0.02).
- **Enrichment**: Verifies generation of risk scores and driver fields in the output.

## Next Steps
- Verify installation of `catboost` and `shap` in the production environment.
- Run `verify_cooper.py` to confirm model spread.
